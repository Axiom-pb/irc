package seyrez.irclogmerger;

import javax.swing.SwingUtilities;

import seyrez.irclogmerger.gui.GUI;

public class IRCLogMerger {
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI gui = new GUI();
					gui.setLocationRelativeTo(null);
					gui.setResizable(false);
					gui.setVisible(true);
				} catch(Exception x) {
					x.printStackTrace();
				}
			}
		});
	}

}
