package seyrez.irclogmerger.gui;

import seyrez.irclogmerger.files.References;

public class LogAppender {
	
	public static void logInfo(final String msg) {
		GUI.log.append(msg + References.NEWLINE);
	}

}
