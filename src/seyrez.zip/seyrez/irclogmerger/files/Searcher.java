package seyrez.irclogmerger.files;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import seyrez.irclogmerger.gui.LogAppender;

public class Searcher {
	
	public static Set<String> logNames = new HashSet<String>();
	public static Set<File> locations = new HashSet<File>();
	
	public Searcher(File f) {
		File destination = new File(References.mainDir + References.FILE_SEPARATOR + "Systems");
		if(destination.exists()) {
			deleteDir(destination);
		}
		searchDir(f);
	}
	
	public static void searchDir(File f) {
		File[] subDir = f.listFiles();
		for(File file : subDir) {
			if(file.isFile() && file.toString().endsWith(".log")) {
				File location = file.getAbsoluteFile();
				locations.add(location);
				String name = file.getName();
				logNames.add(name);
			} else {
				searchDir(file);
			}
		}
	}
	
	private void deleteDir(File f) {
		LogAppender.logInfo("Deleting \"Systems\" directory before starting merge");
		for(File file : f.listFiles()) {
			LogAppender.logInfo("Deleting: " + file.getAbsoluteFile());
			if(file != null) {
				file.delete();
			}
		}
		f.delete();
	}

}
