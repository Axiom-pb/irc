package seyrez.irclogmerger.files;

import java.io.File;

public class References {
	
	public static final String FILE_SEPARATOR = System.getProperty("file.separator");
	public static final String NEWLINE = System.getProperty("line.separator");
	
	public static File mainDir;

}
